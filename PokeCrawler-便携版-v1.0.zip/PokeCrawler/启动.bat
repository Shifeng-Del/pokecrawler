@echo off
chcp 65001 >nul
title PokeCrawler-Server
cd /d %~dp0

REM 清空用户环境可能预置的 PORT，避免误绑 0.0.0.0
set "PORT="

set "PY=%~dp0python\python.exe"
if not exist "%PY%" (
    echo [错误] 未找到 python\python.exe
    echo 请确认整个 PokeCrawler 文件夹已完整解压后重试。
    pause
    exit /b 1
)
if not exist "%~dp0backend\data\poke.db" (
    echo [警告] 未找到数据库文件 backend\data\poke.db，页面可能无法显示数据。
    echo.
)

REM ---- 端口探测：8000 被占则自动改用 8001（只设 API_PORT，保持 127.0.0.1 本机绑定）----
set "API_PORT=8000"
netstat -ano | findstr /R /C:":8000 .*LISTENING" /C:":8000 .*侦听" >nul 2>&1
if not errorlevel 1 (
    echo 8000 端口被其他程序占用，自动改用 8001 端口。
    set "API_PORT=8001"
    netstat -ano | findstr /R /C:":8001 .*LISTENING" /C:":8001 .*侦听" >nul 2>&1
    if not errorlevel 1 (
        echo.
        echo [错误] 8000 和 8001 端口都被占用了，无法启动服务。
        echo 请关闭可能占用端口的程序（例如本程序的另一个窗口）后重试。
        echo.
        pause
        exit /b 1
    )
)

echo.
echo   PokeCrawler 正在启动，请稍候 ...
echo   启动成功后浏览器会自动打开；若未打开，请手动访问：
echo   http://127.0.0.1:%API_PORT%/
echo   使用期间请保持本窗口打开；关闭本窗口将停止服务。
echo.

REM ---- 后台轮询健康检查（最长约 60 秒），就绪后自动打开浏览器 ----
if exist "%SystemRoot%\System32\curl.exe" (
    start "" /b cmd /c "for /l %%i in (1,1,60) do (ping -n 2 127.0.0.1 >nul & curl -s -o nul --max-time 2 http://127.0.0.1:%API_PORT%/api/v1/health && (start http://127.0.0.1:%API_PORT%/ & exit))"
) else (
    start "" /b cmd /c "ping -n 5 127.0.0.1 >nul & start http://127.0.0.1:%API_PORT%/"
)

"%PY%" backend\run.py

echo.
echo   服务已停止。按任意键关闭本窗口。
pause >nul
